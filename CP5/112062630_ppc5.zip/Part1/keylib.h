#ifndef __KEYLIB_H__
#define __KEYLIB_H__
void Init_Keypad(void);
char KeyToChar(void);
char AnyKeyPressed(void);
#endif // __KEYLIB_H__